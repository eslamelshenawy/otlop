@if(Auth::guard('admin')->user()->hasRole('super_admin'))

<a href="{!! route('admin.page.edit',$id) !!}" class="btn btn-info"> <i class="fa fa-edit"></i></a>

    @else
    <button type="button" class="btn btn-info disabled"><i class="fa fa-edit"></i></button>

@endif