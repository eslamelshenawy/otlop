@if($evaluation == 1)
    <td><span class="label label-danger">@lang('admin.Not at all Satisfied')</span></td>
@elseif($evaluation == 2)
    <td><span class="label label-warning">@lang('admin.Slightly Satisfied')</span></td>
@elseif($evaluation == 3)
    <td><span class="label label-primary">@lang('admin.Moderately Satisfied')</span></td>
@elseif($evaluation == 4)
    <td><span class="label label-info">@lang('admin.Quite Satisfied')</span></td>
@elseif($evaluation == 5)
    <td><span class="label label-success">@lang('admin.Extremely Satisfied')</span></td>
@endif