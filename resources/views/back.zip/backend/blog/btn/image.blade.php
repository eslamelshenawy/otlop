    <td>
        <img src="{!! asset('public/upload/blog/'.$image) !!}" style="width: 100px;" class="img-circle" alt="User Image">
    </td>
