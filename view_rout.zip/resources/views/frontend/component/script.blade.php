
<script src="{!! asset('frontend/assets/js/jquery.min.js') !!}"></script>
<script src="{!! asset('frontend/assets/js/bootstrap.min.js') !!}"></script>
<script src="{!! asset('frontend/assets/js/sticky.min.js') !!}"></script>
<script src="{!! asset('frontend/assets/js/plugins.js') !!}"></script>
<script src="{!! asset('frontend/assets/js/main.js') !!}"></script>
<script src="{!! asset('frontend/assets/js/myFunction.js') !!}"></script>
<script src="{{asset('backend/dist/js/myFunction.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/1000hz-bootstrap-validator/0.10.2/validator.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {

        });
    </script>
@stack('js')

