<footer class="main-footer">
    <div class="pull-right hidden-xs">
       {{-- <b>Version</b> 2.4.0--}}
    </div>
    <strong>{!! setting()->copyright !!} </strong>

</footer>