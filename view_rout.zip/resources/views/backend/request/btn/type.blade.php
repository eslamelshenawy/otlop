@if($type == 'owner')
    <td>@lang('admin.Owner')</td>
@else
    <td>@lang('admin.Delivery')</td>
@endif