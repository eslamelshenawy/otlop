@if($features == 1)
    <td><span class="label label-primary">مطعم مميز </span></td>
@else
    <td><span class="label label-default">مطعم غير مميز </span></td>
@endif