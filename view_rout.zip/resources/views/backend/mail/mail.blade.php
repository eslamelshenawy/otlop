<h3> @lang('admin.You have a new contact via the contact form')</h3>

<div>
    {{$bodyMessage}}
</div>

<p> @lang('admin.Sent via')  {{$email}} </p>