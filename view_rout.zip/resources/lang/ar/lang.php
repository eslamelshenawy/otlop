<?php

return
[
    'english'=>'الإنجليزية',
    'arabic'=>'عربى',
];