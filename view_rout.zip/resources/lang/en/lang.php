<?php

return
[
    'english'=>'English',
    'arabic'=>'Arabic',
];